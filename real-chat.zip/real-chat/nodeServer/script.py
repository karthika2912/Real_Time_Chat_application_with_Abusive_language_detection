import numpy as np
import sys
import pandas as pd
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer
nltk.download('stopwords')
import re
import sklearn
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

import pickle
loaded_vectorizer = pickle.load(open('vectorizer.pickle', 'rb'))
loaded_model = pickle.load(open('abusive_spam.model', 'rb'))

def predict_spam(sample_message):
    print(sample_message)
    sample_message = re.sub(pattern='[^a-zA-Z]',repl=' ', string = sample_message)
    sample_message = sample_message.lower()
    sample_message_words = sample_message.split()
    sample_message_words = [word for word in sample_message_words if not word in set(stopwords.words('english'))]
    ps = PorterStemmer()
    final_message = [ps.stem(word) for word in sample_message_words]
    final_message = ' '.join(final_message)
    
    temp = loaded_vectorizer.transform([final_message]).toarray()
   
    k=loaded_model.predict(temp)
    
    return k[0]

t=predict_spam(sys.argv[1]);
if(t==1):
    result="abusive"
else:
    result="non-abusive"
print(result);