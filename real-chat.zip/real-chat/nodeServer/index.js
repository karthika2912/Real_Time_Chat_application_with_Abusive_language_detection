//Node server which will handle socket.io conncections 
const http=require('http');
const {PythonShell} =require('python-shell');
const io =require('socket.io')(8000,{
    cors:{
        origin:'*'
    }
});
const users={};
let f="mes";
//io.on is a socket.io instance which listens 
// socket.on is wrt to connection

io.on('connection',socket=>{
    //console.log("Connection-established");
    socket.on('new-user-joined',name =>{
        console.log("Hello",name);
        users[socket.id]=name;
        socket.broadcast.emit('user-joined',name);
    });
    socket.on('send',message=>{
        
         
    let options = {
		mode: 'text',
		pythonOptions: ['-u'],
        args: [message]
		
		
	};
    PythonShell.run('script.py', options, function (err, result){
		if (err) throw err;
		
		console.log('result: ', result.toString());
         
         res=result.toString();
         l=res.split(",");
         console.log(l[1]);
        if(l[1]=="abusive"){
            message+=" >>>> ABUSIVE";
        }
         socket.broadcast.emit('receive',{message,name:users[socket.id]})
	});
        
    
       
    });

    socket.on('disconnect',message=>{
        socket.broadcast.emit('left',users[socket.id]);
        delete users[socket.id];
                            
    });
     
})